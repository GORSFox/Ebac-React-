import Item from './Components/Item';
import Card from './Components/Card';

const App = () => {
return (
    <>
<h1>App React</h1>
<ul>
<Item>
Hamburguer
</Item>
<Item>
Refrigerante
</Item>
<Item >
Água
</Item>

</ul>
<Card/>
</>
)
}

export default App;

/*export default function App(){
    return(
        <.>Hello world</>
    )*/
